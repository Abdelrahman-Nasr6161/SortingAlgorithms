package sorting.models.Sorts;

import java.util.ArrayList;

public interface Sort {
    public ArrayList<int[]> sort(int[] arr);
    public String getName();
}
